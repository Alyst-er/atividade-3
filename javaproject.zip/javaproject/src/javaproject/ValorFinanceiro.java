import java.util.Scanner;

public class ValorFinanceiro {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o valor presente (VP):");
        double vp = scanner.nextDouble();

        System.out.println("Digite a taxa de juros (em decimal, ex: 0.05 para 5%):");
        double taxa = scanner.nextDouble();

        System.out.println("Digite o número de períodos (n):");
        int n = scanner.nextInt();

        double vf = vp * Math.pow(1 + taxa, n);
        System.out.println("Valor Futuro (VF): " + vf);

        System.out.println("Digite o valor futuro (VF):");
        double novoVf = scanner.nextDouble();

        double novoVp = novoVf / Math.pow(1 + taxa, n);
        System.out.println("Valor Presente (VP): " + novoVp);

        scanner.close();
    }
}
