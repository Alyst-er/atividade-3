def calcular_valor_futuro(pv, i, n):
    return pv * (1 + i) ** n

def calcular_valor_presente(fv, i, n):
    return fv / (1 + i) ** n

pv = float(input("Digite o valor presente: "))
i = float(input("Digite a taxa de juros (em decimal): "))
n = int(input("Digite o número de períodos: "))

fv = calcular_valor_futuro(pv, i, n)
print(f"Valor Futuro: {fv}")

fv_input = float(input("Digite o valor futuro: "))
pv_calculado = calcular_valor_presente(fv_input, i, n)
print(f"Valor Presente: {pv_calculado}")
